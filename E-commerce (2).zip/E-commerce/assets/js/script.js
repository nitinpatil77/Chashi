const products = [
    {
        id: 0,
        name: 'jacket',
        price: 18.45,
        sell: 10.45,
        pink:'40%',
        purple:'New',
        rating: 5,
        images: [
            'https://flone.jamstacktemplates.dev/assets/img/product/fashion/3.jpg',
            'https://flone.jamstacktemplates.dev/assets/img/product/fashion/1.jpg'
        ]
    },
    {
        id: 1,
        name: 'Lorem ipsum fashion coat',
        price: 19.45,
        sell: 11.45,
        pink:'-40%',
        purple:'New',
        rating: 4,
        images: [
            'https://flone.jamstacktemplates.dev/assets/img/product/fashion/4.jpg',
            'https://flone.jamstacktemplates.dev/assets/img/product/fashion/2.jpg'
        ]
    },
    {
        id: 2,
        name: 'jacket',
        price: 18.45,
        sell: 1.45,
        pink:'-10%',
        purple:'New',
        rating: 5,
        images: [
            'https://flone.jamstacktemplates.dev/assets/img/product/fashion/5.jpg',
            'https://flone.jamstacktemplates.dev/assets/img/product/fashion/2.jpg'
        ]
    },
    {
        id: 3,
        name: 'Lorem ipsum jacket',
        price: 20.45,
        sell: 10.45,
        purple:'New',
        rating: 5,
        images: [
            'https://flone.jamstacktemplates.dev/assets/img/product/fashion/6.jpg',
            'https://flone.jamstacktemplates.dev/assets/img/product/fashion/3.jpg'
        ]
    }
];
function renderProducts(products) {
    const contentDiv = document.getElementById('content');
    contentDiv.innerHTML = ''; 
   
    products.forEach((product,i)=> {
      
        const productCard = document.createElement('div');
        productCard.classList.add('col-xl-3', 'col-md-6', 'col-lg-4', 'col-sm-6', 'mb-4');
        productCard.innerHTML = `
            <div class="product-wrap">
                <div class="product-img">
                    <a href="">
                        <img src="${product.images[0]}" class="default-img" alt="${product.name}">
                        <img src="${product.images[1]}" class="hover-img" alt="${product.name}">
                    </a>
                    <div class="product-img-badges">
                        ${product.pink ? `<span class='pink'>${product.pink}</span>` : ''}
                        ${product.purple ? `<span class='purple'>${product.purple}</span>` : ''}
                    </div>
                    <div class="product-action d-flex">
                        <div class="pro-same-action pro-wishlist">
                            <button class="border-0 bg-transparent" title="Add to wishlist" id="add">
                                <i class="fa-regular fa-heart"></i>
                            </button>
                        </div>
                        <div class="pro-same-action pro-cart">
                            <button onclick=addToCard(${products[i].id}) class="border-0 bg-transparent" title="Add to cart"> 
                                <i class="fa-solid fa-cart-shopping"></i>
                                Add to cart
                            </button>
                        </div>
                        <div class="pro-same-action pro-quickview">
                            <button class="border-0 bg-transparent" title="Quick View">
                                <i class="fa-regular fa-eye"></i>
                            </button>
                        </div>
                    </div>
                </div>   
                <div class="product-content text-center">
                    <h3><a href="#" class="text-decoration-none">${product.name}</a></h3>
                    <div class="product-rating">
                        ${generateStars(product.rating)}
                    </div>
                    <div class="product-price">
                        <span> $${product.sell}</span> 
                        <span class="old">$${product.price}</span>
                    </div>
                </div>
            </div>
        `;

        contentDiv.appendChild(productCard);
    });
}
renderProducts(products);

function generateStars(rating) {
    const filledStars = Math.floor(rating);
    const halfStar = rating - filledStars >= 0.5 ? 1 : 0;
    const emptyStars = 5 - filledStars - halfStar;

    let starsHTML = '';
    for (let i = 0; i < filledStars; i++) {
        starsHTML += `<i class="fa-regular fa-star" style="color: #ffa900;"></i>`;
    }
    if (halfStar) {
        starsHTML += `<i class="fa-regular fa-star-half-alt" style="color: #ffa900;"></i>`;
    }
    for (let i = 0; i < emptyStars; i++) {
        starsHTML += `<i class="far fa-star"></i>`;
    }

    return starsHTML;
}

//function for the add to cart and set the data in localstorage
var addtocart = [];
function addToCard(product_id) { 
    addtocart[product_id]=products[product_id];
    localStorage.setItem('addto',JSON.stringify(addtocart));
    document.getElementsByClassName('count-style')[0].innerHTML = addtocart.length;
}



renderProducts(products);


