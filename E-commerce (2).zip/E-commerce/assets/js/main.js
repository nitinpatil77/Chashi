const product = [
  {
    id: 0,
    name: "Lorem ipsum jacket",
    price: 17.45,
    sell: 10.45,
    pink: "40%",
    purple: "New",
    rating: 5,
    images: [
      "https://flone.jamstacktemplates.dev/assets/img/product/fashion/3.jpg",
      "https://flone.jamstacktemplates.dev/assets/img/product/fashion/1.jpg",
    ],
  },
  {
    id: 1,
    name: "Lorem ipsum fashion coat",
    price: 17.45,
    sell: 11.45,
    pink: "-40%",
    purple: "New",
    rating: 4,
    images: [
      "https://flone.jamstacktemplates.dev/assets/img/product/fashion/4.jpg",
      "https://flone.jamstacktemplates.dev/assets/img/product/fashion/2.jpg",
    ],
  },
  {
    id: 2,
    name: "Lorem ipsum fashion coat",
    price: 17.45,
    sell: 1.45,
    pink: "-10%",
    purple: "New",
    rating: 5,
    images: [
      "https://flone.jamstacktemplates.dev/assets/img/product/fashion/5.jpg",
      "https://flone.jamstacktemplates.dev/assets/img/product/fashion/2.jpg",
    ],
  },
  {
    id: 3,
    name: "Lorem ipsum jacket",
    price: 17.45,
    sell: 10.45,
    purple: "New",
    rating: 5,
    images: [
      "https://flone.jamstacktemplates.dev/assets/img/product/fashion/6.jpg",
      "https://flone.jamstacktemplates.dev/assets/img/product/fashion/3.jpg",
    ],
  },
];

let cartPage = document.getElementById("content");

let mainProduct = () => {
  return (cartPage.innerHTML = product
    .map((item) => {
      let { id, name, price, sell, pink, purple, rating, images } = item;
      return `
        <div class="col-xl-3 col-md-6 col-lg-4 col-sm-6">
            <div class="product-wrap">
                <div class="product-img">
                    <a href="">
                        <img src="${
                          images[0]
                        }" class="default-img" alt="${name}">
                        <img src="${images[1]}" class="hover-img" alt="${name}">
                    </a>
                    <div class="product-img-badges">
                        ${pink ? `<span class='pink'>${pink}</span>` : ""}
                        ${purple ? `<span class='purple'>${purple}</span>` : ""}
                    </div>
                    <div class="product-action d-flex">
                        <div class="pro-same-action pro-wishlist">
                            <button class="border-0 bg-transparent" title="Add to wishlist" id="add">
                                <i class="fa-regular fa-heart"></i>
                            </button>
                        </div>
                        <div class="pro-same-action pro-cart">
                            <button onclick=fun(${id}) class="border-0 bg-transparent" title="Add to cart"> 
                                <i class="fa-solid fa-cart-shopping"></i>
                                Add to cart
                            </button>
                        </div>
                        <div class="pro-same-action pro-quickview">
                            <button class="border-0 bg-transparent" title="Quick View">
                                <i class="fa-regular fa-eye"></i>
                            </button>
                        </div>
                    </div>
                </div>   
                <div class="product-content text-center">
                    <h3><a href="#" class="text-decoration-none">${name}</a></h3>
                    <div class="product-rating">
                        ${generateStars(rating)}
                    </div>
                    <div class="product-price">
                        <span> $${sell}</span> 
                        <span class="old">$${price}</span>
                    </div>
                </div>
            </div>
        </div>
        `;
    })
    .join(""));
};
mainProduct();

function generateStars(rating) {
  const filledStars = Math.floor(rating);
  const halfStar = rating - filledStars >= 0.5 ? 1 : 0;
  const emptyStars = 5 - filledStars - halfStar;

  let starsHTML = "";
  for (let i = 0; i < filledStars; i++) {
    starsHTML += `<i class="fa-regular fa-star" style="color: #ffa900;"></i>`;
  }
  if (halfStar) {
    starsHTML += `<i class="fa-regular fa-star-half-alt" style="color: #ffa900;"></i>`;
  }
  for (let i = 0; i < emptyStars; i++) {
    starsHTML += `<i class="far fa-star"></i>`;
  }

  return starsHTML;
}

function fun(product_id) {
  console.log(product_id);
}
