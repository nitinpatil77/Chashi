const checkbox = document.getElementById('price');

// Add an event listener to the checkbox
checkbox.addEventListener('change', function() {
    // Check if the checkbox is checked
    if (this.checked) {
        const cartPage = document.getElementById('addcart');

        // Find the products with name equal to 'jacket'
        const foundProducts = productJSON.filter(item => item.name === 'jacket');
        // Render found products if they exist
        if (foundProducts.length > 0) {
            cartPage.innerHTML = foundProducts.map(({ name, price, images }) => `
                <div class="col-xl-3 col-md-6 col-lg-4 col-sm-6">
                    <div class="shopping-cart-img">
                        <a href="#">
                            <img alt="" src="${images[0]}" class="img-fluid">
                        </a>
                    </div>
                    <div class="shopping-cart-title">
                        <h4><a href="#"> ${name} </a></h4>
                        <span>${price}</span>
                    </div>
                </div>
            `).join('');
        } else {
            // If no product with the specified name is found
            cartPage.innerHTML = "No product found.";
        }
    } else {
        // If the checkbox is unchecked, you might want to render all products again
        // or clear the cartPage, depending on your requirements.
        console.log('Checkbox is not checked');``
    }
});

const searchBoxGetId = document.getElementById('search');

searchBoxGetId.addEventListener('click', function() {
    const searchBoxValue = document.getElementById('search').value;
    const cartPage = document.getElementById('addcart');

        // Find the products with name equal to 'jacket'
        const foundProducts = productJSON.filter(item => item.name === searchBoxValue);
        // Render found products if they exist
        if (foundProducts.length > 0) {
            cartPage.innerHTML = foundProducts.map(({ name, price, images }) => `
                <div class="col-xl-3 col-md-6 col-lg-4 col-sm-6">
                    <div class="shopping-cart-img">
                        <a href="#">
                            <img alt="" src="${images[0]}" class="img-fluid">
                        </a>
                    </div>
                    <div class="shopping-cart-title">
                        <h4><a href="#"> ${name} </a></h4>
                        <span>${price}</span>
                    </div>
                </div>
            `).join('');
        } 
});
