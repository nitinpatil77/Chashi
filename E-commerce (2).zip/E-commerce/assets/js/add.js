var productJSON = [];

window.onload = () => {
    productJSON = JSON.parse(localStorage.getItem('addto')) || []; 
     // if there is no data in local storage its return empty array

    if(productJSON.length===0){
        document.getElementById('empty-cart').style.display='block';
        document.getElementById('fill-cart').style.display='none';
    }
    else{
        document.getElementById('empty-cart').style.display='none';
        // load cart
        addtocartPage();
        document.getElementsByClassName('count-style')[0].innerHTML = productJSON.length;
    }
   
}

addtocartPage=()=> {
    const cartPage = document.getElementById('addcart');
    cartPage.innerHTML = productJSON.map((item) => {
        var{id,name,price,images,sell}=item;
        return `
            <tr>
                <td class="product-thumbnail">
                    <a href="#">
                        <img class="img-fluid" src="${images[0]}" alt="">
                    </a>
                </td>
                <td class="product-name">
                    <a href="#">${name}</a>
                </td>
                <td class="product-price-cart">
                    <span class="amount old">${price}</span>
                    <span class="amount">${sell}</span>
                </td>
                <td class="product-quantity">
                    <div class="cart-plus-minus">
                        <button class="dec qtybutton">-</button>
                        <input class="cart-plus-minus-box" type="text" readonly="" value="1">
                        <button class="inc qtybutton" >+</button>
                    </div>
                </td>
                <td class="product-subtotal">0</td>
                <td class="product-remove">
                    <button onclick="removeItem()"><i class="fa fa-times"></i></button>
                </td>
            </tr>
        `;
    }).join('');
}

// removeitem
let removeItem = (index) => {

    productJSON.splice(index, 1);
    document.getElementsByClassName('count-style')[0].innerHTML = productJSON.length;
    //new data set on local storage
    localStorage.setItem('addto', JSON.stringify(productJSON)) || [];
    if(productJSON.length===0){
        document.getElementById('empty-cart').style.display='block';
        document.getElementById('fill-cart').style.display='none';
    }
    else{
        addtocartPage();
    }
}
